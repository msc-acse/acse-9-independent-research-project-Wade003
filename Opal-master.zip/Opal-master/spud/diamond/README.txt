Diamond:
http://amcg.ese.ic.ac.uk/index.php?title=Local:Diamond

The new Fluidity options system:
http://amcg.ese.ic.ac.uk/index.php?title=Local:Options

Running Fluidity from new options:
http://amcg.ese.ic.ac.uk/index.php?title=Local:Running_Fluidity_from_new_options
